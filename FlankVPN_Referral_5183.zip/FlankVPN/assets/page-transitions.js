(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion) return;

  let navigating = false;
  const internalPage = (link) => {
    if (!link || link.target || link.hasAttribute('download')) return false;
    if (link.origin !== window.location.origin) return false;
    if (!/\.html?$/i.test(link.pathname)) return false;
    if (link.pathname === window.location.pathname && !link.search) return false;
    return true;
  };

  document.addEventListener('click', (event) => {
    const link = event.target.closest('a[href]');
    if (!internalPage(link) || event.defaultPrevented || event.button !== 0 ||
        event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || navigating) return;

    event.preventDefault();
    navigating = true;
    document.documentElement.classList.add('flank-is-leaving');

    // A short pause lets the outgoing page soften before the next document loads.
    window.setTimeout(() => {
      window.location.href = link.href;
    }, 220);
  });
})();
