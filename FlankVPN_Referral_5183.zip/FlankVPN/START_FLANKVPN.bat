@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo FlankVPN: http://127.0.0.1:5183
start "" http://127.0.0.1:5183
where py >nul 2>nul
if %errorlevel%==0 (py -m http.server 5183 --bind 127.0.0.1) else (python -m http.server 5183 --bind 127.0.0.1)
pause
